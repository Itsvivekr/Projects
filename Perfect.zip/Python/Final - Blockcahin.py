import socket
import requests
import qrcode
import hashlib
import json
import os
import datetime

from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.lib.units import inch
from reportlab.lib import colors

# ================= SETTINGS =================
BOT_TOKEN = "8521086827:AAHA-hxwDASnj7uU5dhNyOMEsa-7YisjT-A"
CHAT_ID = "8228944852"

UDP_IP = "0.0.0.0"
UDP_PORT = 4210

PDF_FILE = "PH_Report.pdf"
QR_FILE = "PH_Report_QR.png"
BLOCKCHAIN_FILE = "ph_blockchain.json"

# ================= UDP SETUP =================
sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
sock.bind((UDP_IP, UDP_PORT))

print("Listening for UDP Broadcast on port", UDP_PORT)

# ================= CLASSIFY pH =================
def classify_ph(ph_value):
    ph_value = int(ph_value)

    if 900 <= ph_value <= 1300:
        return "BASE", "No", "Non-Organic"

    elif 1400 <= ph_value <= 1900:
        return "NORMAL", "Yes", "Organic"

    elif 2100 <= ph_value <= 2700:
        return "ACID", "No", "Non-Organic"

    else:
        return "OUTRANGE", "No", "Non-Organic"


# ================= BLOCKCHAIN FUNCTIONS =================

def calculate_hash(index, timestamp, data, previous_hash):
    block_string = f"{index}{timestamp}{data}{previous_hash}"
    return hashlib.sha256(block_string.encode()).hexdigest()

def load_blockchain():
    if os.path.exists(BLOCKCHAIN_FILE):
        with open(BLOCKCHAIN_FILE, "r") as f:
            return json.load(f)
    return []

def save_blockchain(chain):
    with open(BLOCKCHAIN_FILE, "w") as f:
        json.dump(chain, f, indent=4)

def add_block(data):
    chain = load_blockchain()

    index = len(chain)
    timestamp = str(datetime.datetime.now())
    previous_hash = chain[-1]["hash"] if chain else "0"

    block_hash = calculate_hash(index, timestamp, data, previous_hash)

    block = {
        "index": index,
        "timestamp": timestamp,
        "data": data,
        "previous_hash": previous_hash,
        "hash": block_hash
    }

    chain.append(block)
    save_blockchain(chain)

    print("🔐 Block Added")
    print("Hash:", block_hash)

    return block_hash

def retrieve_block_by_hash(search_hash):
    chain = load_blockchain()

    for block in chain:
        if block["hash"] == search_hash:
            return block
    return None


# ================= MAIN LOOP =================
while True:
    data, addr = sock.recvfrom(1024)
    received_text = data.decode().strip()
    print("Received:", received_text)

    try:
        parts = received_text.split(",")
        ph_value_str = parts[-2]   # Take 1158 from data
    except:
        print("Invalid Data Format")
        continue

    status, editable, organic = classify_ph(ph_value_str)

    # ================= ADD TO BLOCKCHAIN =================
    block_data = {
        "pH": ph_value_str,
        "status": status,
        "editable": editable,
        "type": organic
    }

    block_hash = add_block(block_data)

    # ================= RETRIEVE BLOCK =================
    retrieved_block = retrieve_block_by_hash(block_hash)

    # ================= CREATE PDF =================
    doc = SimpleDocTemplate(PDF_FILE)
    elements = []
    styles = getSampleStyleSheet()

    elements.append(Paragraph("IoT Organic pH Lab Report", styles["Heading1"]))
    elements.append(Spacer(1, 0.3 * inch))

    # Current Data Table
    table_data = [
        ["pH Value", "Status", "Editable", "Type"],
        [ph_value_str, status, editable, organic]
    ]

    table = Table(table_data, colWidths=[1.2*inch]*4)
    table.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,0), colors.lightblue),
        ('TEXTCOLOR', (0,0), (-1,0), colors.white),
        ('ALIGN', (0,0), (-1,-1), 'CENTER'),
        ('GRID', (0,0), (-1,-1), 1, colors.black)
    ]))

    elements.append(table)
    elements.append(Spacer(1, 0.3 * inch))

    # Blockchain Hash
    elements.append(Paragraph("Blockchain Hash:", styles["Heading2"]))
    elements.append(Paragraph(block_hash, styles["Normal"]))
    elements.append(Spacer(1, 0.3 * inch))

    # Retrieved Block Data
    if retrieved_block:
        elements.append(Paragraph("Retrieved Blockchain Record:", styles["Heading2"]))
        elements.append(Spacer(1, 0.2 * inch))

        retrieved_data = [
            ["Index", str(retrieved_block["index"])],
            ["Timestamp", retrieved_block["timestamp"]],
            ["pH", retrieved_block["data"]["pH"]],
            ["Status", retrieved_block["data"]["status"]],
            ["Editable", retrieved_block["data"]["editable"]],
            ["Type", retrieved_block["data"]["type"]],
            ["Previous Hash", retrieved_block["previous_hash"]],
            ["Hash", retrieved_block["hash"]],
        ]

        retrieved_table = Table(retrieved_data, colWidths=[1.5*inch, 3*inch])
        retrieved_table.setStyle(TableStyle([
            ('GRID', (0,0), (-1,-1), 1, colors.black),
            ('BACKGROUND', (0,0), (0,-1), colors.lightgrey),
        ]))

        elements.append(retrieved_table)

    doc.build(elements)
    print("PDF Updated with Blockchain Data")

    # ================= SEND TO TELEGRAM =================
    try:
        url = f"https://api.telegram.org/bot{BOT_TOKEN}/sendDocument"

        with open(PDF_FILE, "rb") as f:
            response = requests.post(
                url,
                data={"chat_id": CHAT_ID},
                files={"document": f},
                timeout=10
            )

        result = response.json()

        if result.get("ok"):
            file_id = result["result"]["document"]["file_id"]

            file_info = requests.get(
                f"https://api.telegram.org/bot{BOT_TOKEN}/getFile?file_id={file_id}",
                timeout=10
            ).json()

            file_path = file_info["result"]["file_path"]
            download_link = f"https://api.telegram.org/file/bot{BOT_TOKEN}/{file_path}"

            qr = qrcode.make(download_link)
            qr.save(QR_FILE)

            print("QR Code Updated")
            print("Download Link:", download_link)

        else:
            print("Telegram Error:", result)

    except Exception as e:
        print("Telegram Connection Failed:", e)

    print("----------------------------------")
