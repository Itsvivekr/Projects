import socket
import requests
import qrcode
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.lib.units import inch

# ================= SETTINGS =================
BOT_TOKEN = "8747540971:AAHmgfV2LesfnXNscPYvD7QMfQShZxFx1Yg"
CHAT_ID = "1169359211"

UDP_IP = "0.0.0.0"
UDP_PORT = 4210
PDF_FILE = "PH_Report.pdf"

# ================= UDP SETUP =================
sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
sock.bind((UDP_IP, UDP_PORT))

print("Listening for UDP Broadcast on port", UDP_PORT)

while True:
    data, addr = sock.recvfrom(1024)
    received_text = data.decode()
    print("Received:", received_text)

    # ================= CREATE / UPDATE PDF =================
    doc = SimpleDocTemplate(PDF_FILE)
    elements = []
    styles = getSampleStyleSheet()

    elements.append(Paragraph("IoT Hydroponic pH Report", styles["Heading1"]))
    elements.append(Spacer(1, 0.5 * inch))
    elements.append(Paragraph(f"Received Data: {received_text}", styles["Normal"]))

    doc.build(elements)
    print("PDF Updated")

    # ================= SEND TO TELEGRAM =================
    url = f"https://api.telegram.org/bot{BOT_TOKEN}/sendDocument"

    with open(PDF_FILE, "rb") as f:
        response = requests.post(url, data={"chat_id": CHAT_ID}, files={"document": f})

    file_id = response.json()["result"]["document"]["file_id"]

    # ================= GET DOWNLOAD LINK =================
    file_info = requests.get(
        f"https://api.telegram.org/bot{BOT_TOKEN}/getFile?file_id={file_id}"
    ).json()

    file_path = file_info["result"]["file_path"]

    download_link = f"https://api.telegram.org/file/bot{BOT_TOKEN}/{file_path}"

    print("Download Link:", download_link)

    # ================= GENERATE QR =================
    qr = qrcode.make(download_link)
    qr.save("PH_Report_QR.png")

    print("QR Updated Successfully")
    print("----------------------------------")
