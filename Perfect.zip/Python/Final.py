import socket
import requests
import qrcode
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.lib.units import inch
from reportlab.lib import colors

# ================= SETTINGS =================
BOT_TOKEN = "8521086827:AAHA-hxwDASnj7uU5dhNyOMEsa-7YisjT-A"
CHAT_ID = "8228944852"

UDP_IP = "0.0.0.0"
UDP_PORT = 4210
PDF_FILE = "PH_Report.pdf"
QR_FILE = "PH_Report_QR.png"

# ================= UDP SETUP =================
sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
sock.bind((UDP_IP, UDP_PORT))

print("Listening for UDP Broadcast on port", UDP_PORT)

# ================= FUNCTION TO CLASSIFY pH =================
def classify_ph(ph_value):
    ph_value = int(ph_value)
    if 900 <= ph_value <= 1300:
        status = "BASE"
        editable = "No"        # not editable
        organic = "Non-Organic"  # new column
    elif 1400 <= ph_value <= 1900:
        status = "NORMAL"
        editable = "Yes"       # editable
        organic = "Organic"
    elif 2100 <= ph_value <= 2700:
        status = "ACID"
        editable = "No"        # not editable
        organic = "Non-Organic"
    else:
        status = "OUTRANGE"
        editable = "No"
        organic = "Non-Organic"
    return status, editable, organic

# ================= MAIN LOOP =================
while True:
    data, addr = sock.recvfrom(1024)
    received_text = data.decode().strip()
    print("Received:", received_text)

    try:
        ph_value_str, _ = received_text.split(",")
    except:
        ph_value_str = received_text.split(",")[0]

    status, editable, organic = classify_ph(ph_value_str)

    # ================= CREATE PDF =================
    doc = SimpleDocTemplate(PDF_FILE)
    elements = []
    styles = getSampleStyleSheet()

    # Heading
    elements.append(Paragraph("IoT Organic pH Lab Report", styles["Heading1"]))
    elements.append(Spacer(1, 0.3 * inch))

    # Data Table with extra column "Type"
    table_data = [
        ["pH Value", "Status", "Editable", "Type"],
        [ph_value_str, status, editable, organic]
    ]

    table_style = TableStyle([
        ('BACKGROUND', (0,0), (-1,0), colors.lightblue),
        ('TEXTCOLOR', (0,0), (-1,0), colors.white),
        ('ALIGN', (0,0), (-1,-1), 'CENTER'),
        ('FONTNAME', (0,0), (-1,0), 'Helvetica-Bold'),
        ('FONTSIZE', (0,0), (-1,0), 12),
        ('BOTTOMPADDING', (0,0), (-1,0), 8),
        ('GRID', (0,0), (-1,-1), 1, colors.black)
    ])

    table = Table(table_data, colWidths=[1.2*inch]*4)
    table.setStyle(table_style)
    elements.append(table)
    elements.append(Spacer(1, 0.3 * inch))

    # Notes / Interpretation
    notes = (
        "- BASE (900-1300): Nutrient solution is alkaline. Not editable.\n"
        "- NORMAL (1400-1900): Ideal pH range. Editable.\n"
        "- ACID (2100-2700): Nutrient solution is acidic. Not editable.\n"
        "- OUTRANGE: Check sensor or solution. Not editable.\n"
        "- Type column shows whether the solution is Organic or Non-Organic."
    )
    elements.append(Paragraph("Interpretation:", styles["Heading2"]))
    elements.append(Paragraph(notes, styles["Normal"]))

    doc.build(elements)
    print("PDF Updated Successfully")

    # ================= SEND TO TELEGRAM =================
    url = f"https://api.telegram.org/bot{BOT_TOKEN}/sendDocument"

    with open(PDF_FILE, "rb") as f:
        response = requests.post(url, data={"chat_id": CHAT_ID}, files={"document": f})

    result = response.json()
    if result.get("ok"):
        file_id = result["result"]["document"]["file_id"]

        # Get download link
        file_info = requests.get(
            f"https://api.telegram.org/bot{BOT_TOKEN}/getFile?file_id={file_id}"
        ).json()
        file_path = file_info["result"]["file_path"]
        download_link = f"https://api.telegram.org/file/bot{BOT_TOKEN}/{file_path}"

        # ================= GENERATE QR =================
        qr = qrcode.make(download_link)
        qr.save(QR_FILE)
        print("QR Code Updated Successfully")
        print("Download Link:", download_link)
    else:
        print("Error sending PDF to Telegram:", result)

    print("----------------------------------")
