// App UN: organic_ph
// App PW: Projectiot@123 
// Hotspot UN: projectiot
// Hotspot PW: projectiot

#include <WiFi.h>
#include <WiFiUdp.h>
#include <LiquidCrystal.h>
#include <ArduinoIoTCloud.h>
#include <Arduino_ConnectionHandler.h>

// ================== IoT Cloud ==================
const char DEVICE_LOGIN_NAME[]  = "d51f6059-7bb0-457a-bb36-75b96aa5df5f";
const char SSID[]               = "projectiot";
const char PASS[]               = "projectiot";
const char DEVICE_KEY[]         = "OvBg1!M6ZaGDP?tzC6k8MuFWd";

void onStatusChange();
void onPhvalueChange();
void onAcideChange();
void onBaseeChange();
void onNormeChange();

// Cloud Variables
String status;
int phvalue;
bool acide;
bool basee;
bool norme;

// ================== UDP ==================
WiFiUDP udp;
#define UDP_PORT 4210

// ================== Pin Definitions ==================
#define PHPIN 33
LiquidCrystal lcd(2, 15, 19, 18, 5, 4);

// ================== Globals ==================
unsigned long tsLastReport = 0;
#define REPORTING_PERIOD_MS 1000

bool showPHValue = true;
unsigned long phToggleTimer = 0;

// ================== IoT Properties ==================
void initProperties(){
  ArduinoCloud.setBoardId(DEVICE_LOGIN_NAME);
  ArduinoCloud.setSecretDeviceKey(DEVICE_KEY);

  ArduinoCloud.addProperty(status, READWRITE, ON_CHANGE, onStatusChange);
  ArduinoCloud.addProperty(phvalue, READWRITE, ON_CHANGE, onPhvalueChange);
  ArduinoCloud.addProperty(acide, READWRITE, ON_CHANGE, onAcideChange);
  ArduinoCloud.addProperty(basee, READWRITE, ON_CHANGE, onBaseeChange);
  ArduinoCloud.addProperty(norme, READWRITE, ON_CHANGE, onNormeChange);
}

WiFiConnectionHandler ArduinoIoTPreferredConnection(SSID, PASS);

// ================== Setup ==================
void setup() {

  Serial.begin(115200);
  lcd.begin(16, 2);

  initProperties();
  ArduinoCloud.begin(ArduinoIoTPreferredConnection);

  analogReadResolution(12);

  WiFi.mode(WIFI_STA);
  WiFi.begin(SSID, PASS);

  udp.begin(UDP_PORT);
}

// ================== Loop ==================
void loop() {

  ArduinoCloud.update();

  if (millis() - tsLastReport > REPORTING_PERIOD_MS) {

    int pHAnalog = analogRead(PHPIN);
    phvalue = pHAnalog;

    String pHStatus = "OUTRANGE";

    // ===== Range Logic =====
    if (pHAnalog >= 900 && pHAnalog <= 1500) {
      pHStatus = "BASE";
      acide = false;
      basee = true;
      norme = false;
    }
    else if (pHAnalog >= 1500 && pHAnalog <= 2000) {
      pHStatus = "NORMAL";
      acide = false;
      basee = false;
      norme = true;
    }
    else if (pHAnalog >= 2000 && pHAnalog <= 2700) {
      pHStatus = "ACID";
      acide = true;
      basee = false;
      norme = false;
    }
    else {
      acide = false;
      basee = false;
      norme = false;
    }

    // IMPORTANT: update status AFTER classification
    status = pHStatus;

    // ===== LCD =====
    lcd.setCursor(0, 0);
      lcd.print("pH:" + String(pHAnalog));
    lcd.setCursor(0, 1);
    lcd.print("Status:" + pHStatus);
    lcd.print("     ");

      

    // ===== UDP =====
    if (WiFi.status() == WL_CONNECTED) {
      String packet = String(pHAnalog) + "," + pHStatus;
      udp.beginPacket("255.255.255.255", UDP_PORT);
      udp.print(packet);
      udp.endPacket();
    }

    tsLastReport = millis();
  }
}

// ===== Callbacks (Required but empty) =====
void onStatusChange() {}
void onPhvalueChange() {}
void onAcideChange() {}
void onBaseeChange() {}
void onNormeChange() {}
